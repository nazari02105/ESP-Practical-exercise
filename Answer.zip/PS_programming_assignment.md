<div style="direction:rtl;line-height:300%;"><font face="XB Zar" size=5>
<div align=center>
<font face="B Titr" size=30>
<p></p><p></p>
به نام خدا
<p></p>
</font>
<p></p>

<font color=blue>
<br>
    پروژه
آمار و احتمال مهندسی 
<br>
مدرس: دکتر مطهری
</font>
<p></p>

<p></p>
<font color=#FF7500>
پاییز 1400
<br>
دانشگاه صنعتی شریف
<br>
دانشکده مهندسی کامپیوتر
<br>
    علی نظری
    <br>
    99102401
    </font>
<br>
<br>
</div>
</font>
</div>
<br>

<br>

<p style = 'color:blue;' align=center>
    جواب ها با رنگ ابی نوشته شده اند
</p>

<div style="direction:rtl;line-height:300%;text-align:justify;" align="justify"><font face="XB Zar" size=5>
<font color=red size=7>
<p></p>
<div align=center> بخش اول : تولید متغیرهای تصادفی</div>
</font>
<hr>    
در این بخش، تنها با استفاده از تابع ()np.random.random که یک متغیر تصادفی uniform(0,1) می‌دهد، بایستی سایر متغیرهای تصادفی معروف را تولید کنید. برای هر کدام از این متغیرهای تصادفی، یک تابع بنویسید که پارامترهای لازم را گرفته و یک متغیر تصادفی از آن توزیع را خروجی دهد. سپس برای بررسی صحت کارکرد توابع، یک آرایه از این متغیر تصادفی ها ایجاد کرده و هیستوگرام آن‌ها را رسم کنید.
<br>
روش تولید هر یک از متغیرها را به صورت دقیق توضیح دهید. واضح است که می‌توانید از توابعی که خودتان نوشته‌اید در کنار ()np.random.random استفاده کنید (مثلاً استفاده از bernoulli در binomial)

</font></div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">متغیر برنولی در واقع یعنی ما کاری را انجام می دهیم که دو حالت موفقیت و شکست دارد و احتمل موفقیت،
p
    است و احتمال شکست هم 
    1-p
    پس ما برای تولید این متغیر، یک متغیر یونیفرم که مقداری بین ۰ و ۱ دارد را میگیریم و بررسی میکنیم آن بزرگتر از پارامتر این توزیع برنولی هست یا خیر. اگر بود که یعنی ما شکست خورده ایم و ۰ بر میگردانیم و در غیر این صورت، اگر مقدار تابع یونیفرم، گوچکتر از 
    p
    بود، ما پیروز شده ایم و یک را برمیگردانیم و در تعداد بالا که از این توزیع، متغیر بگیریم، به توزیع برنولی می رسیم که میانگین آن، 
    p 
    است و واریانس آن 
    p(1-p)
    و در کد موجود، این مورد صدق میکند و نموداری هم که می کشیم، از همین توزیع با پارامتر مشخص شده پیروی میکند.
</div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    برای تولید متغیر تصادفی باینوم، میدانیم که همان توزیع برنولی است ولی ما آزمایش را به جای یکبار
    n 
    بار انجام میدهیم در نتیجه این تویع، دو تا پارامتر ورودی دارد که به تعداد 
    n
    ما آزمایش را انجام می دهیم و باز هم دو  حالت شکست و پیروزی داریم که دوباره متغیری تصادفی از یونیفرم تولید میکنیم و اگر بزرگتر از 
    p
    بود، یعنی شست خوردیم و ۰ می شود نتیجه و ارگر کمتر از 
    p
    بود، یعنی پیروز شده ایم و یک بر می گردانیم.
    حال چون ما یک متغیر تصادفی می خواهیم برگردانیم و نه چند تا، جمع تعداد یک ها یعنی تعداد پیروزی هایمان را بر میگردانیم و به عنوان متغیر تصادفی استفاده می کنیم.
    در این حالت هم میانگین 
    np
    است که کد زده شده، این موضوع را رعایت کرده و وارینس هم
    np(1-p)
    است که رعایت شده و شکل نمودار هم پیروی می کند از این توزیع
</div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    برای تولید توزیع هندسی، مانند این است که سکه ای داریم که با احتمال 
    p
    پشت می آید و ما می خواهیم بدانیم چند بار سکه را بیندازیم تا برای اولین بار پشت بیاید و این تعداد دفعات انداختن سکه میشود همان متغیر تصادفی ما. حال برای تولید آن از فرمول 
    [ln(uniform)]/ln(1-p)
    استفاده میکنیم که به ما همان تعداد دفعات انداختن سکه برای دیدن اولین پشت را می دهد.
    برای این توزیع، میانگین
    (1-p)/p
    است و واریانس 
    (1-p)/p^2
    و کد نوشته شده، از این دو مورد پیروی می کند. و نموداری هم که در نهایت کشیده شده، از فرم کلی نمودار های این توزیع، پیروی می کند.
</div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    در توزیع نمایی، یعنی در واحد زمانی ما به طور متوسط، لاندا بار اتفاق مدنظر ما می افتد. حال چقدر باید صبر کنیم تا اتفاق مدنظر ما برای اولین بار بیفتد. در اینجا از توزیع نمایی استفاده میکنیم و آن مدت زمانی که صبر میکنیم، همان متغیر تصادفی با توزیع نمایی است و برای تولید آن از فرمول
    -ln(uniform)/l
    استفاده میکنیم که در واقع همان زمان صبر کردن را به ما میدهد و از این طریق، متغیر تصادفی مدنظر تولید می شود و حال با تولید تعداد زیادی از این متغیر تصادفی، می توانیم میانگین و واریانس و نمودار را رسم کنیم.
    میانگین که برابر با
    1/l
    هست و واریانس برابر با
    1/l^2
    است و کد موجود، از این دو مورد پیروی می کند و نمودار کشیده شده هم از قالب کلی این توزیع پیروی می کند.
</div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    برای تولید توزیع گاما، ما می توانیم از توزیع نمایی استفاده کنیم به این شکل که 
    l
    بار متغیر تصادفی نمایی تولید می کنیم و بعد همه این ها را جمع می کنیم و با تقسیم این جمع به پارامتر
    k
    این توطیع، یک متغیر تصادفی از نوع گاما داریم و سپس چندین متغیر تصادفی از این توزیع تولید می کنیم و میانگین و واریانس آن را می گیریم و نمودار را هم رسم می کنیم که میانگین برابر با
    l/k
    است و واریانس برابر با
    l/k^2
    است که کد زده شده، از این ها پیروی می کند و نموداری هم که در نهایت تولید می شود ا شکل و فرم کلی این توزیع پیروی می کند.
</div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    در توزیع پوآسون می خواهیم ببینیم در یک بازه زمانی مشخص، میانگین چه تعداد بار پشت در پرتاب سکه می افتد که برای اینکار باز هم از توزیع نمایی می توانیم کمک بگیریم.
    برای اینکار، آنقدر توزیع نمایی را تکرار می کنیم تا جمع متغیر ای تصادفی تولید شده، از یک بیشتر شود و تعداد بار هایی که نمایی را انجام دادیم را ذخیره میکنیم و آن را به عنوان متغیر تصادفی ای که از توزیع پوآسون پیروی می کند، گزارش می دهیم.
    برای این توزیع هم می توانیم میانگین و واریانس و نمودار را بکشیم تا مطمئن شویم که درست است. میانگین و واریانس آن، هر دو برابر با 
    l*t 
    است که کد پایین پیروی می کند از این موضوع و نمودار تولید شده هم ا ز نمودار این توزیع پیروی می کند.
</div>


```python
import numpy as np
import matplotlib.pyplot as plt
import statistics


# Bernoulli
def bernoulli(p):
    """
    returns a bernoulli random variable with probability p
    """
    u = np.random.random()
    if u <= p:
        return 1
    return 0


n = 10000
p = 0.3
bernoulliList = []
for i in range(n):
    randomVariable = bernoulli(p)
    bernoulliList.append(randomVariable)
print(sum(bernoulliList) / len(bernoulliList))  # it will be p which is true for bernoulli
print(statistics.variance(bernoulliList))  # it will be p(1-p) which is true for bernoulli
xAxis = [0, 1]
yAxis = [bernoulliList.count(1), bernoulliList.count(0)]
fig = plt.figure(figsize=(10, 5))
# creating the bar plot
plt.bar(xAxis, yAxis, color='maroon', width=0.4)
plt.xlabel("Victory or Not")
plt.ylabel("Number of Victory and Lose")
plt.title("Bernoulli Distribution")
plt.show()


# Binomial
def binomial(n, p):
    """
    returns a binomial random variable with probability p and number of trials of n
    """
    myList = []
    for i in range(n):
        b = np.random.random()
        if b < p:
            myList.append(1)
        else:
            myList.append(0)
    return sum(myList)


number = 1000
n = 1000
p = 0.3
binomialList = []
for i in range(number):
    u = binomial(n, p)
    binomialList.append(u)
print(sum(binomialList) / len(binomialList))  # it will be np which is true for binomial
print(statistics.variance(binomialList))  # it will be npq which is true for binomial
binomialDict = {}
for i in binomialList:
    if i in binomialDict.keys():
        binomialDict[i] += 1
    else:
        binomialDict[i] = 1
xAxis = binomialDict.keys()
yAxis = binomialDict.values()
fig = plt.figure(figsize=(10, 5))
# creating the bar plot
plt.bar(xAxis, yAxis, color='maroon', width=0.4)
plt.xlabel("Number of Successes")
plt.ylabel("Number of times to view any number of wins")
plt.title("Binomial Distribution")
plt.show()


# geometric
def geometric(p):
    """
    returns a geometric random variable with probability p
    """
    g = np.floor(np.log(np.random.random()) / np.log(1 - p))
    return g


n = 10000
geometricList = []
for i in range(n):
    u = geometric(0.5)
    geometricList.append(u)
print(sum(geometricList) / len(geometricList))  # it will be 1-p/p which is true for geometric
print(statistics.variance(geometricList))  # it will be (1-p)/p^2 which is true for geometric
geometricDict = {}
for i in geometricList:
    if i in geometricDict.keys():
        geometricDict[i] += 1
    else:
        geometricDict[i] = 1
xAxis = geometricDict.keys()
yAxis = geometricDict.values()
fig = plt.figure(figsize=(10, 5))
# creating the bar plot
plt.bar(xAxis, yAxis, color='maroon', width=0.4)
plt.title("Geometric Distribution")
plt.show()


# exponential
def exponential(l):
    """
    returns an exponential random variable with parameter lambda
    """
    e = (-1 / l) * np.log(np.random.random())
    return e


n = 10000
exponentialList = []
for i in range(n):
    u = exponential(0.5)
    exponentialList.append(u)
print(sum(exponentialList) / len(exponentialList))  # it will be 1/l which is true for exponential
print(statistics.variance(exponentialList))  # it will be 1/(l^2) which is true for exponential
exponentialDict = {}
for i in exponentialList:
    i *= 100
    i = np.floor(i)
    i /= 100
    if i in exponentialDict.keys():
        exponentialDict[i] += 1
    else:
        exponentialDict[i] = 1
xAxis = exponentialDict.keys()
yAxis = exponentialDict.values()
fig = plt.figure(figsize=(10, 5))
# creating the bar plot
plt.bar(xAxis, yAxis, color='maroon', width=0.4)
plt.title("Exponential Distribution")
plt.show()


# gamma
def gamma(l, k):
    """
    returns a gamma random variable with parameters lambda and k  (hint : you can use exponential(lambda) function to create gamma)
    """
    myList = l * [0]
    for i in range(l):
        myList[i] = exponential(1)
    return sum(myList) / k


n = 10000
l = 4
k = 10
gammaList = []
for i in range(n):
    u = gamma(l, k)
    gammaList.append(u)
print(statistics.mean(gammaList))  # it will be l/k which is true for gamma
print(statistics.variance(gammaList))  # it will be l/(k^2) which is true for gamma
gammaDict = {}
for i in gammaList:
    i *= 100
    i = np.floor(i)
    i /= 100
    if i in gammaDict.keys():
        gammaDict[i] += 1
    else:
        gammaDict[i] = 1
xAxis = gammaDict.keys()
yAxis = gammaDict.values()
fig = plt.figure(figsize=(10, 5))
# creating the bar plot
plt.bar(xAxis, yAxis, color='maroon', width=0.4)
plt.title("Gamma Distribution")
plt.show()


# poisson
def poisson(l, t):
    """
    returns a poisson random variable with parameter lambda*t (hint: you can use exponential(lambda) function to create poisson)
    """
    counter = -1
    totalSum = 0
    while True:
        counter += 1
        totalSum += exponential(l * t)
        if totalSum > 1:
            break
    return counter


n = 10000
l = 5
t = 2
poissonList = []
for i in range(n):
    u = poisson(l, t)
    poissonList.append(u)
print(statistics.mean(poissonList))  # it will be l*t which is true for poisson
print(statistics.variance(poissonList))  # it will be l*t which is true for poisson
poissonDict = {}
for i in poissonList:
    if i in poissonDict.keys():
        poissonDict[i] += 1
    else:
        poissonDict[i] = 1
xAxis = poissonDict.keys()
yAxis = poissonDict.values()
fig = plt.figure(figsize=(10, 5))
# creating the bar plot
plt.bar(xAxis, yAxis, color='maroon', width=0.4)
plt.title("Poisson Distribution")
plt.show()
```

    0.3068
    0.21269502950295033
    


    
![png](output_2_1.png)
    


    300.191
    202.60112012012013
    


    
![png](output_2_3.png)
    


    0.988
    1.9896549654965499
    


    
![png](output_2_5.png)
    


    2.000991834799504
    4.0279319974293815
    


    
![png](output_2_7.png)
    


    0.3986460787426817
    0.038745061628190226
    


    
![png](output_2_9.png)
    


    10.0208
    10.06697405740574
    


    
![png](output_2_11.png)
    


<div style="direction:rtl;line-height:300%;text-align:justify;" align="justify"><font face="XB Zar" size=5>
<font color=red size=7>
<p></p>
<div align=center> بخش دوم : بررسی داده‌های کشتی تایتانیک</div>
</font>
<hr>
در این بخش داده‌های مربوط به کشتی تایتانیک را خوانده و بررسی خواهید کرد. پس از اینکه داده‌ها را خواندید، با استفاده از 
تابع head می‌توانید اطلاعاتی که هر ستون نشان می‌دهد را بررسی کنید. همانطور که از داده‌های پیداست، تعدادی از سطرها، اطلاعاتشان ناقص است و NaN در آنها قرار گرفته است. روش‌های متنوعی برای مواجه با این مشکل وجود دارد. برای پر کردن اطلاعات ستون Age، می‌خواهیم از میانگین سن داده‌هایی که شبیه هستند، استفاده کنیم.
<br>
برای اینکار، بایستی یک ستون جدید به دیتافریم اضافه کنید که نمایانگر عنوان افراد می‌باشد. این عنوان، از اسم افراد برداشته می‌شود. به طور مثال، عنوان Mr. Owen Harris برابر Mr می‌باشد. 
<br>
پس از اضافه کردن این ستون، سن افرادی که سن آنها NaN می‌باشد را برابر میانگین سن افراد آن عنوان قرار می‌دهیم.

</font></div>


```python
import re
import math
import numpy as np
import pandas as pd

pd.set_option('mode.chained_assignment', None)
data = pd.read_csv("titanic.csv")
print(data.head())


def add_title_column(df):
    df["title"] = ""
    counter = -1
    for i in df["Name"]:
        counter += 1
        txt = i
        x = re.findall(", .*\\.", txt)
        found = x[0]
        found = found[2:]
        found = found[:-1]
        df["title"][counter] = found
    return df


data = add_title_column(data)
print(data.head())


def fix_age_nan(df):
    age_mean = {}
    counter = -1
    for j in df["Name"]:
        counter += 1
        found = df["title"][counter]
        age = data["Age"][counter]
        if not math.isnan(age):
            if found in age_mean.keys():
                age_mean[found].append(age)
            else:
                age_mean[found] = [age]
    for key in age_mean.keys():
        age_mean[key] = np.mean(age_mean[key])
    counter = -1
    for i in data["Age"]:
        counter += 1
        if math.isnan(i):
            data["Age"][counter] = age_mean[data["title"][counter]]
    return df


data = fix_age_nan(data)
print(data.head())
print(data.isnull().sum())
```

       PassengerId  Survived  Pclass  \
    0            1         0       3   
    1            2         1       1   
    2            3         1       3   
    3            4         1       1   
    4            5         0       3   
    
                                                    Name     Sex   Age  SibSp  \
    0                            Braund, Mr. Owen Harris    male  22.0      1   
    1  Cumings, Mrs. John Bradley (Florence Briggs Th...  female  38.0      1   
    2                             Heikkinen, Miss. Laina  female  26.0      0   
    3       Futrelle, Mrs. Jacques Heath (Lily May Peel)  female  35.0      1   
    4                           Allen, Mr. William Henry    male  35.0      0   
    
       Parch            Ticket     Fare Cabin Embarked  
    0      0         A/5 21171   7.2500   NaN        S  
    1      0          PC 17599  71.2833   C85        C  
    2      0  STON/O2. 3101282   7.9250   NaN        S  
    3      0            113803  53.1000  C123        S  
    4      0            373450   8.0500   NaN        S  
       PassengerId  Survived  Pclass  \
    0            1         0       3   
    1            2         1       1   
    2            3         1       3   
    3            4         1       1   
    4            5         0       3   
    
                                                    Name     Sex   Age  SibSp  \
    0                            Braund, Mr. Owen Harris    male  22.0      1   
    1  Cumings, Mrs. John Bradley (Florence Briggs Th...  female  38.0      1   
    2                             Heikkinen, Miss. Laina  female  26.0      0   
    3       Futrelle, Mrs. Jacques Heath (Lily May Peel)  female  35.0      1   
    4                           Allen, Mr. William Henry    male  35.0      0   
    
       Parch            Ticket     Fare Cabin Embarked title  
    0      0         A/5 21171   7.2500   NaN        S    Mr  
    1      0          PC 17599  71.2833   C85        C   Mrs  
    2      0  STON/O2. 3101282   7.9250   NaN        S  Miss  
    3      0            113803  53.1000  C123        S   Mrs  
    4      0            373450   8.0500   NaN        S    Mr  
       PassengerId  Survived  Pclass  \
    0            1         0       3   
    1            2         1       1   
    2            3         1       3   
    3            4         1       1   
    4            5         0       3   
    
                                                    Name     Sex   Age  SibSp  \
    0                            Braund, Mr. Owen Harris    male  22.0      1   
    1  Cumings, Mrs. John Bradley (Florence Briggs Th...  female  38.0      1   
    2                             Heikkinen, Miss. Laina  female  26.0      0   
    3       Futrelle, Mrs. Jacques Heath (Lily May Peel)  female  35.0      1   
    4                           Allen, Mr. William Henry    male  35.0      0   
    
       Parch            Ticket     Fare Cabin Embarked title  
    0      0         A/5 21171   7.2500   NaN        S    Mr  
    1      0          PC 17599  71.2833   C85        C   Mrs  
    2      0  STON/O2. 3101282   7.9250   NaN        S  Miss  
    3      0            113803  53.1000  C123        S   Mrs  
    4      0            373450   8.0500   NaN        S    Mr  
    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age              0
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    title            0
    dtype: int64
    

<div style="direction:rtl;line-height:300%;text-align:justify;" align="justify"><font face="XB Zar" size=5>
<ol>
    <li>
با استفاده از ویژگی title که در بخش قبل اضافه کردید، نمودار میله‌ای افراد زنده مانده و نمانده با هر یک از عنوان ها را رسم کنید.
    </li>
    <li>
هیستوگرام  age را 
رسم کنید و توزیع جمعیت مسافران را مشاهده نمایید (براي سن از بازه هاي مناسب استفاده نمایید.) یک بار نیز این کار را براي دو دسته ي زنده
ماده و نمانده انجام ندهید. حال این نمودارها را با جداسازي جنسیت بکشید تا چهار نمودار داشته باشید. مشاهدات خود را ثبت کنید.
</li>
    <li>
نمودار Heatmap یک نمایش گرافیکی دو بعدي از دادگان است که ارتباط ویژگی هاي مختلف را نشان می دهد. علاوه بر ارتباط بین  هرویژگی با
زنده ماندن، بین خود ویژگی ها نیز ممکن است ارتباط معناداري باشد. براي دریافتن این ارتباطات میتوان همبستگی یا  Correlation بین ستون
ها را مقایسه کرد. میتوان براي مقایسه جامع از  Heatmap استفاده کرد و همبستگی بین ستون ها را نشان داد. Correlation Heat map
ویژگی ها و همچنین  survival را رسم نمایید. کدام ویژگی ها داراي همبستگی زیادي هستند؟ 

</li>
    <li>
     نمودار جعبه اي مقدار  Fare را براي 
  3 گروه  Pclass و براي دو حالت   Survived  0,1 (یعنی در مجموع   6 نمودار) رسم کنید. چه نتیجه اي در رابطه با پراکندگی داده‌ها میتوان گرفت؟

</div>


<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    إرای بخش سوم این سوال، با توجه به 
    heat map 
    کشیده شده، می فهمیم که ارتباط 
    Fare 
    و 
    Survived 
    بسیار زیاد است و خیلی به هم مرتبط هستند و از دیگر ستون ها، ارتباط ستون 
    Parch
    هم با ستون
    Survived
    کمی مشخص است و می توان در نظر گرفت کمی ارتباط دارند.
    از بین ویژگی ها با هم هم میتوان به ارتباط
    Pclass 
    و 
    SibSp
    اشاره کرد و 
    کمی
    Age
    و 
    Fare
    و همینطور
    ارتباط بسیار زیادی بین 
    Parch 
    و 
    SibSp
    وجود دارد که خیلی این ارتباط قوی و زیاد هست
    و ارتباط 
    Fare 
    و
    Parch
    هم مشهود است.
</div>
<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    برای بخش چهارم این سوال، همانطور که از نمودار های جعبه ای مشخص است برای حالت
    pclass1 
    و
    survived
    پراکندگی داده ها کم است ولی داده های پرت وجود دارد که از نمودار جعبه ای کنار گذاشته شده اند.
    برای حالت 
    pclass 1
    و 
    not survie
    پراکندگی داده ها مقداری بیشتر است و فاصله 
    max
    با چارک سوم مقداری زیاد هست.
    برای حالت 
    pclass2
    و Survived
    هم داده های پرت بسیار کمتر است ولی باز فاصله 
    max 
    با چارک سوم زیاد هست و تفاوت این حالت با حالت قبل این است که فاصله میانه یا همان چارک دوم با چارک اول مقداری بیشتر است ولی خب فاصله چارک اول با 
    min
    کمتر است.
    برای حالت 
    pclass 2 
    و 
    not survived
    هم تقربا پراکندگی متعادل است و فاصله هر بخش از بخش قبل از خود، برابر است و تقریبا متعادل است.
    برای حالت 
    pclass3 
    و 
    survived
    می توان اینطور گفت که پراکندگی داده ها کم است و بخش های مختلف با کنار گذاشتن داده های پرت، بههم نزدیک هستند.
    برای بخش آخر یعنی 
    pclass3 
    و 
    not survived 
    هم داریم که پراکندگی داده به شدت کم است ولی داده های پرت بسیار بسیار زیاد هستند و از همه بخش های دیگر بیشتر است.
</div>


```python
import re
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn

pd.set_option('mode.chained_assignment', None)
data = pd.read_csv("titanic.csv")

def add_title_column(df):
    df["title"] = ""
    counter = -1
    for i in df["Name"]:
        counter += 1
        txt = i
        x = re.findall(", .*\\.", txt)
        found = x[0]
        found = found[2:]
        found = found[:-1]
        df["title"][counter] = found
    return df


data = add_title_column(data)

def fix_age_nan(df):
    age_mean = {}
    counter = -1
    for j in df["Name"]:
        counter += 1
        found = df["title"][counter]
        age = data["Age"][counter]
        if not math.isnan(age):
            if found in age_mean.keys():
                age_mean[found].append(age)
            else:
                age_mean[found] = [age]
    for key in age_mean.keys():
        age_mean[key] = np.mean(age_mean[key])
    counter = -1
    for i in data["Age"]:
        counter += 1
        if math.isnan(i):
            data["Age"][counter] = age_mean[data["title"][counter]]
    return df


data = fix_age_nan(data)

#####################
#   draw bar plots  #
#####################
alive = {}
notAlive = {}
counter = -1
for i in data["Survived"]:
    counter += 1
    title = data["title"][counter]
    if i == 1:
        if title in alive.keys():
            alive[title] += 1
        else:
            alive[title] = 1
    else:
        if title in notAlive.keys():
            notAlive[title] += 1
        else:
            notAlive[title] = 1

xAxis1 = []
xAxis2 = []
yAxis1 = []
yAxis2 = []
for key in alive.keys():
    xAxis1.append(key)
    yAxis1.append(alive[key])
for key in notAlive.keys():
    xAxis2.append(key)
    yAxis2.append(notAlive[key])
plt.bar(xAxis1, yAxis1)
plt.title('alive guys number')
plt.xlabel('title')
plt.ylabel('number')
plt.show()
plt.bar(xAxis2, yAxis2)
plt.title('not alive guys number')
plt.xlabel('title')
plt.ylabel('number')
plt.show()


#####################
#   draw histograms #
#####################
allAge = {}
for i in data["Age"]:
    i = np.floor(i)
    if i in allAge.keys():
        allAge[i] += 1
    else:
        allAge[i] = 1
xAxis = allAge.keys()
yAxis = allAge.values()

plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution')
plt.xlabel('age')
plt.ylabel('number')
plt.show()


alive = {}
notAlive = {}
counter = -1
for i in data["Age"]:
    counter += 1
    i = np.floor(i)
    if data["Survived"][counter] == 1:
        if i in alive.keys():
            alive[i] += 1
        else:
            alive[i] = 1
    else:
        if i in notAlive.keys():
            notAlive[i] += 1
        else:
            notAlive[i] = 1

xAxis = alive.keys()
yAxis = alive.values()
plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution for alive guys')
plt.xlabel('age')
plt.ylabel('number')
plt.show()

xAxis = notAlive.keys()
yAxis = notAlive.values()
plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution for not alive guys')
plt.xlabel('age')
plt.ylabel('number')
plt.show()


menAlive = {}
menNotAlive = {}
womenAlive = {}
womenNotAlive = {}
counter = -1
for i in data["Age"]:
    counter += 1
    intAge = np.floor(i)
    if data["Sex"][counter] == "male" and data["Survived"][counter] == 1:
        if intAge in menAlive.keys():
            menAlive[intAge] += 1
        else:
            menAlive[intAge] = 1
    elif data["Sex"][counter] == "male" and data["Survived"][counter] == 0:
        if intAge in menNotAlive.keys():
            menNotAlive[intAge] += 1
        else:
            menNotAlive[intAge] = 1
    elif data["Sex"][counter] == "female" and data["Survived"][counter] == 1:
        if intAge in womenAlive.keys():
            womenAlive[intAge] += 1
        else:
            womenAlive[intAge] = 1
    else:
        if intAge in womenNotAlive.keys():
            womenNotAlive[intAge] += 1
        else:
            womenNotAlive[intAge] = 1
xAxis = []
yAxis = []
for key in menAlive.keys():
    xAxis.append(key)
    yAxis.append(menAlive[key])
plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution for alive men')
plt.xlabel('age')
plt.ylabel('number')
plt.show()

xAxis = []
yAxis = []
for key in menNotAlive.keys():
    xAxis.append(key)
    yAxis.append(menNotAlive[key])
plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution for not alive men')
plt.xlabel('age')
plt.ylabel('number')
plt.show()

xAxis = []
yAxis = []
for key in womenAlive.keys():
    xAxis.append(key)
    yAxis.append(womenAlive[key])
plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution for alive women')
plt.xlabel('age')
plt.ylabel('number')
plt.show()

xAxis = []
yAxis = []
for key in womenNotAlive.keys():
    xAxis.append(key)
    yAxis.append(womenNotAlive[key])
plt.hist2d(xAxis, yAxis, bins=5)
plt.title('age distribution for not alive women')
plt.xlabel('age')
plt.ylabel('number')
plt.show()

#####################
#   draw heatmaps   #
#####################
plt.figure(figsize=(16, 6))
heatmap = seaborn.heatmap(data.corr(), vmin=-1, vmax=1, annot=True, cmap='BrBG')
heatmap.set_title('Correlation Heatmap', fontdict={'fontsize': 18}, pad=12)
plt.show()

#####################
#   draw boxplots   #
#####################
p1s1 = []
p1s0 = []
p2s1 = []
p2s0 = []
p3s1 = []
p3s0 = []

counter = -1
for i in data["Pclass"]:
    counter += 1
    if i == 1:
        if data["Survived"][counter] == 1:
            p1s1.append(data["Fare"][counter])
        else:
            p1s0.append(data["Fare"][counter])
    if i == 2:
        if data["Survived"][counter] == 1:
            p2s1.append(data["Fare"][counter])
        else:
            p2s0.append(data["Fare"][counter])
    if i == 3:
        if data["Survived"][counter] == 1:
            p3s1.append(data["Fare"][counter])
        else:
            p3s0.append(data["Fare"][counter])

plt.boxplot(p1s1)
plt.title("For pClass1 and survived")
plt.show()

plt.boxplot(p1s0)
plt.title("For pClass1 and not survived")
plt.show()

plt.boxplot(p2s1)
plt.title("For pClass2 and survived")
plt.show()

plt.boxplot(p2s0)
plt.title("For pClass2 and not survived")
plt.show()

plt.boxplot(p3s1)
plt.title("For pClass3 and survived")
plt.show()

plt.boxplot(p3s0)
plt.title("For pClass3 and not survived")
plt.show()

```


    
![png](output_7_0.png)
    



    
![png](output_7_1.png)
    



    
![png](output_7_2.png)
    



    
![png](output_7_3.png)
    



    
![png](output_7_4.png)
    



    
![png](output_7_5.png)
    



    
![png](output_7_6.png)
    



    
![png](output_7_7.png)
    



    
![png](output_7_8.png)
    



    
![png](output_7_9.png)
    



    
![png](output_7_10.png)
    



    
![png](output_7_11.png)
    



    
![png](output_7_12.png)
    



    
![png](output_7_13.png)
    



    
![png](output_7_14.png)
    



    
![png](output_7_15.png)
    


<div style="direction:rtl;line-height:300%;text-align:justify;" align="justify"><font face="XB Zar" size=5>
<font color=red size=7>
<p></p>
<div align=center> بخش سوم : آزمون فرض</div>
</font>
<hr>
در این بخش با استفاده از t-test ، به بررسی این مسئله می‌پردازیم که که توزیع سن زنان و مردان یکی است یا نه. برای این منظور، دو زیرمجموعه‌ی 100 عضوی از آقایان و خانم‌ها از داده‌ی تاینانیک به صورت رندوم جدا کنید. فرض صفر ما این است که توزیع این دو زیرمجموعه، تفاوت معناداری ندارد. برای بررسی صحت این فرض، ابتدا t-value را حساب کنید. سپس با استفاده از جدول t و یا با استفاده از ()scipy.stats.t.cdf مقدار p-value را محاسبه و گزارش کنید. همچنین توضیح دهید که این مقدار p-value، چه حرفی در رابطه با فرض صفر ما می‌زند.

</font></div>

<div style="direction:rtl;line-height:300%;text-align:justify;color:blue;">
    برای این بخش، مقدار
    p-value
    را  با خطای نوع اول مدظر و در واقع، آن مرز مورد نظر مقایسه میکنیم.  اگر 
    p-value
    بیشتر بود، نمی توانیم فرض صفر را رد کنیم ولی اگر کمتر بود، می توانیم فرض صفر را رد کنیم
    و در واقع این دو داده تفاوت معناداری خواهند داشت.
    برای این بخش هم حالتی که بازه اطمینان را در نظر نگیریم محاسبه شده است اول و بعد از آن حالت بازه اطمینان ۹۵ درصد در نظر گرفته شده است که هر دو حالت با هم نوشته شده است تا بتوان تصمیم بهتری گرفت.
    در مورد یک طرفه و دو طرفه بودن هم چون ما دقیقا برابری رو می خواهیم چک کنیم، چه بزرگتر شود مقدار و چه کوچکتر شود، فرض صفر رد می شود پس هر دو طرف را باید در نظر بگیریم پس دو طرفه می نویسیم.
</div>


```python
import numpy as np
import re
import statistics
import math
import random
import pandas as pd
from scipy import stats

pd.set_option('mode.chained_assignment', None)
data = pd.read_csv("titanic.csv")


def add_title_column(df):
    df["title"] = ""
    counter = -1
    for i in df["Name"]:
        counter += 1
        txt = i
        x = re.findall(", .*\\.", txt)
        found = x[0]
        found = found[2:]
        found = found[:-1]
        df["title"][counter] = found
    return df


data = add_title_column(data)


def fix_age_nan(df):
    age_mean = {}
    counter = -1
    for j in df["Name"]:
        counter += 1
        found = df["title"][counter]
        age = data["Age"][counter]
        if not math.isnan(age):
            if found in age_mean.keys():
                age_mean[found].append(age)
            else:
                age_mean[found] = [age]
    for key in age_mean.keys():
        age_mean[key] = np.mean(age_mean[key])
    counter = -1
    for i in data["Age"]:
        counter += 1
        if math.isnan(i):
            data["Age"][counter] = age_mean[data["title"][counter]]
    return df


data = fix_age_nan(data)


def get_male_subset(data, n=100):
    """
    return a randomly selected subset of n males
    subset should be a dataframe
    """
    subset = []
    allMen = []
    counter = -1
    for i in data["Age"]:
        i = np.floor(i)
        counter += 1
        if data["Sex"][counter] == "male":
            allMen.append(i)
    for i in range(n):
        subset.append(allMen[random.randint(0, len(allMen) - 1)])
    return subset


def get_female_subset(data, n=100):
    """
    return a randomly selected subset of n females
    subset should be a dataframe
    """
    subset = []
    allWomen = []
    counter = -1
    for i in data["Age"]:
        i = np.floor(i)
        counter += 1
        if data["Sex"][counter] == "female":
            allWomen.append(i)
    for i in range(n):
        subset.append(allWomen[random.randint(0, len(allWomen) - 1)])
    return subset


mainMenAges = get_male_subset(data, 100)
mainWomenAges = get_female_subset(data, 100)

menMean = statistics.mean(mainMenAges)
womenMean = statistics.mean(mainWomenAges)
menVariance = statistics.variance(mainMenAges)
womenVariance = statistics.variance(mainWomenAges)

print("No confidence interval:")
n = 100
t = (menMean - womenMean) / np.sqrt((menVariance / n) + (womenVariance / n))
twoSidePValue = stats.t.sf(np.abs(t), n - 1) * 2

print("two sided p-value is ", twoSidePValue)

if twoSidePValue < 0.05:
    print("by two sided t-test, null hypothesis can not be rejected so their distribution is the same.")
else:
    print("by two sided t-test, null hypothesis can be rejected so their distribution is not the same.")

print("###################################")

print("With confidence interval:")
tValue, pValue = stats.ttest_rel(mainMenAges, mainWomenAges)
twoSidePValue = pValue * 2

print("two sided p-value is ", twoSidePValue)

if twoSidePValue < 0.05:
    print("by two sided t-test, null hypothesis can not be rejected so their distribution is the same.")
else:
    print("by two sided t-test, null hypothesis can be rejected so their distribution is not the same.")

```

    No confidence interval:
    two sided p-value is  0.0006588587650036757
    by two sided t-test, null hypothesis can not be rejected so their distribution is the same.
    ###################################
    With confidence interval:
    two sided p-value is  0.0020086947320985885
    by two sided t-test, null hypothesis can not be rejected so their distribution is the same.
    

<div style="direction:rtl;line-height:300%;text-align:justify;" align="justify"><font face="XB Zar" size=5>
<font color=red size=7>
<p></p>
<div align=center> بخش چهارم : پیاده سازی Naive bayes (امتیازی)</div>
</font>
<hr>
در این بخش باید به وسیله برخی از ستون ها بتوانید ستون Survived را پیش بینی کنید.
 <hr>
 برای این منظور باید naive bayes classifier را پیاده سازی کنید که نحوه پیاده سازی آن را میتوانید از لینک زیر مطالعه کنید.
<a href="url">https://inblog.in/Categorical-Naive-Bayes-Classifier-implementation-in-Python-dAVqLWkf7E</a>
</font></div>


```python
# use ['Embarked','Parch','SibSp','Pclass','Sex'] for features
import pandas as pd
from sklearn.naive_bayes import GaussianNB, CategoricalNB
from sklearn.preprocessing import OrdinalEncoder
from sklearn.metrics import accuracy_score, recall_score, precision_score
from sklearn.metrics import f1_score, classification_report
from sklearn.model_selection import train_test_split
from statsmodels.stats.outliers_influence import variance_inflation_factor
import seaborn as sns
import warnings

sns.set()
warnings.filterwarnings('ignore')

titanic_df = pd.read_csv("titanic.csv")

print(titanic_df.head())
print(titanic_df.describe())
print(titanic_df.info())
print(titanic_df.dtypes)
print(titanic_df.isnull().sum())

features = titanic_df.columns.tolist()
features.remove("Cabin")
features.remove("PassengerId")
features.remove("Name")
features.remove("Age")
features.remove("Ticket")
features.remove("Embarked")
features.remove("Fare")

for var in features:
    print(titanic_df[var].value_counts().sort_values(ascending=False) / titanic_df.shape[0])
    print('=' * 30)
    print()

encoder = OrdinalEncoder()
data_encoded = encoder.fit_transform(titanic_df[features])
titanic_df_encoded = pd.DataFrame(data_encoded, columns=features)
print(data_encoded)
print(titanic_df_encoded)
print(titanic_df_encoded.head())

vif = pd.DataFrame()
vif["VIF"] = [variance_inflation_factor(titanic_df_encoded.values, i) for i in range(len(features))]
vif["Features"] = features
print(vif)

X_train, X_test, y_train, y_test = train_test_split(titanic_df_encoded.drop('Survived', axis=1),
                                                    titanic_df_encoded['Survived'], test_size=0.2, random_state=143)

cnb = CategoricalNB()
cnb.fit(X_train, y_train)

gnb = GaussianNB()
gnb.fit(X_train, y_train)

y_pred_cnb = cnb.predict(X_train)
y_prob_pred_cnb = cnb.predict_proba(X_train)
# how did our model perform?
count_misclassified = (y_train != y_pred_cnb).sum()

print("CategoricalNB")
print("=" * 30)
print('Misclassified samples: {}'.format(count_misclassified))
accuracy = accuracy_score(y_train, y_pred_cnb)
print('Accuracy: {:.2f}'.format(accuracy))

y_pred_gnb = gnb.predict(X_test)
y_prob_pred_gnb = gnb.predict_proba(X_test)
# how did our model perform?
count_misclassified = (y_test != y_pred_gnb).sum()

print("GaussianNB")
print("=" * 30)
print('Misclassified samples: {}'.format(count_misclassified))
accuracy = accuracy_score(y_test, y_pred_gnb)
print('Accuracy: {:.2f}'.format(accuracy))

print("Recall score : ", recall_score(y_train, y_pred_cnb, average='micro'))
print("Precision score : ", precision_score(y_train, y_pred_cnb, average='micro'))
print("F1 score : ", f1_score(y_train, y_pred_cnb, average='micro'))

print("Recall score : ", recall_score(y_test, y_pred_gnb, average='micro'))
print("Precision score : ", precision_score(y_test, y_pred_gnb, average='micro'))
print("F1 score : ", f1_score(y_test, y_pred_gnb, average='micro'))

print(classification_report(y_train, y_pred_cnb))

print(classification_report(y_test, y_pred_gnb))
```

       PassengerId  Survived  Pclass  \
    0            1         0       3   
    1            2         1       1   
    2            3         1       3   
    3            4         1       1   
    4            5         0       3   
    
                                                    Name     Sex   Age  SibSp  \
    0                            Braund, Mr. Owen Harris    male  22.0      1   
    1  Cumings, Mrs. John Bradley (Florence Briggs Th...  female  38.0      1   
    2                             Heikkinen, Miss. Laina  female  26.0      0   
    3       Futrelle, Mrs. Jacques Heath (Lily May Peel)  female  35.0      1   
    4                           Allen, Mr. William Henry    male  35.0      0   
    
       Parch            Ticket     Fare Cabin Embarked  
    0      0         A/5 21171   7.2500   NaN        S  
    1      0          PC 17599  71.2833   C85        C  
    2      0  STON/O2. 3101282   7.9250   NaN        S  
    3      0            113803  53.1000  C123        S  
    4      0            373450   8.0500   NaN        S  
           PassengerId    Survived      Pclass         Age       SibSp  \
    count   891.000000  891.000000  891.000000  714.000000  891.000000   
    mean    446.000000    0.383838    2.308642   29.699118    0.523008   
    std     257.353842    0.486592    0.836071   14.526497    1.102743   
    min       1.000000    0.000000    1.000000    0.420000    0.000000   
    25%     223.500000    0.000000    2.000000   20.125000    0.000000   
    50%     446.000000    0.000000    3.000000   28.000000    0.000000   
    75%     668.500000    1.000000    3.000000   38.000000    1.000000   
    max     891.000000    1.000000    3.000000   80.000000    8.000000   
    
                Parch        Fare  
    count  891.000000  891.000000  
    mean     0.381594   32.204208  
    std      0.806057   49.693429  
    min      0.000000    0.000000  
    25%      0.000000    7.910400  
    50%      0.000000   14.454200  
    75%      0.000000   31.000000  
    max      6.000000  512.329200  
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 891 entries, 0 to 890
    Data columns (total 12 columns):
     #   Column       Non-Null Count  Dtype  
    ---  ------       --------------  -----  
     0   PassengerId  891 non-null    int64  
     1   Survived     891 non-null    int64  
     2   Pclass       891 non-null    int64  
     3   Name         891 non-null    object 
     4   Sex          891 non-null    object 
     5   Age          714 non-null    float64
     6   SibSp        891 non-null    int64  
     7   Parch        891 non-null    int64  
     8   Ticket       891 non-null    object 
     9   Fare         891 non-null    float64
     10  Cabin        204 non-null    object 
     11  Embarked     889 non-null    object 
    dtypes: float64(2), int64(5), object(5)
    memory usage: 83.7+ KB
    None
    PassengerId      int64
    Survived         int64
    Pclass           int64
    Name            object
    Sex             object
    Age            float64
    SibSp            int64
    Parch            int64
    Ticket          object
    Fare           float64
    Cabin           object
    Embarked        object
    dtype: object
    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64
    0    0.616162
    1    0.383838
    Name: Survived, dtype: float64
    ==============================
    
    3    0.551066
    1    0.242424
    2    0.206510
    Name: Pclass, dtype: float64
    ==============================
    
    male      0.647587
    female    0.352413
    Name: Sex, dtype: float64
    ==============================
    
    0    0.682379
    1    0.234568
    2    0.031425
    4    0.020202
    3    0.017957
    8    0.007856
    5    0.005612
    Name: SibSp, dtype: float64
    ==============================
    
    0    0.760943
    1    0.132435
    2    0.089787
    3    0.005612
    5    0.005612
    4    0.004489
    6    0.001122
    Name: Parch, dtype: float64
    ==============================
    
    [[0. 2. 1. 1. 0.]
     [1. 0. 0. 1. 0.]
     [1. 2. 0. 0. 0.]
     ...
     [0. 2. 0. 1. 2.]
     [1. 0. 1. 0. 0.]
     [0. 2. 1. 0. 0.]]
         Survived  Pclass  Sex  SibSp  Parch
    0         0.0     2.0  1.0    1.0    0.0
    1         1.0     0.0  0.0    1.0    0.0
    2         1.0     2.0  0.0    0.0    0.0
    3         1.0     0.0  0.0    1.0    0.0
    4         0.0     2.0  1.0    0.0    0.0
    ..        ...     ...  ...    ...    ...
    886       0.0     1.0  1.0    0.0    0.0
    887       1.0     0.0  0.0    0.0    0.0
    888       0.0     2.0  0.0    1.0    2.0
    889       1.0     0.0  1.0    0.0    0.0
    890       0.0     2.0  1.0    0.0    0.0
    
    [891 rows x 5 columns]
       Survived  Pclass  Sex  SibSp  Parch
    0       0.0     2.0  1.0    1.0    0.0
    1       1.0     0.0  0.0    1.0    0.0
    2       1.0     2.0  0.0    0.0    0.0
    3       1.0     0.0  0.0    1.0    0.0
    4       0.0     2.0  1.0    0.0    0.0
            VIF  Features
    0  1.225304  Survived
    1  2.515120    Pclass
    2  2.097648       Sex
    3  1.521925     SibSp
    4  1.511199     Parch
    CategoricalNB
    ==============================
    Misclassified samples: 139
    Accuracy: 0.80
    GaussianNB
    ==============================
    Misclassified samples: 39
    Accuracy: 0.78
    Recall score :  0.8047752808988764
    Precision score :  0.8047752808988764
    F1 score :  0.8047752808988764
    Recall score :  0.7821229050279329
    Precision score :  0.7821229050279329
    F1 score :  0.7821229050279329
                  precision    recall  f1-score   support
    
             0.0       0.83      0.85      0.84       433
             1.0       0.76      0.73      0.75       279
    
        accuracy                           0.80       712
       macro avg       0.80      0.79      0.79       712
    weighted avg       0.80      0.80      0.80       712
    
                  precision    recall  f1-score   support
    
             0.0       0.81      0.87      0.84       116
             1.0       0.72      0.62      0.67        63
    
        accuracy                           0.78       179
       macro avg       0.77      0.74      0.75       179
    weighted avg       0.78      0.78      0.78       179
    
    

<div style="direction:rtl;line-height:300%;text-align:justify;" align="justify"><font face="XB Zar" size=5>
<font color=red size=7>
<p></p>
</font>
 <hr>
در این بخش، جواب اصلی همان کد بالا است ولی من خودم از طریق همان لینک چیزهایی خواندم برای همین پیشبینی از طریق چند فیچر که نتایجش جالب بودو البته خب شاید به نوعی بتوان جواب این بخش هم دانست آن را ولی اگر احساس کردید که این ها جواب نیستند، 
    ignore 
    کنید بی زحمت بخش پایین را.
    در کل اینجوری هست که با مدل های مختلف، و با استفاده از همین 
    train test 
    بخش 
    survived 
    را با فیچر های گفته شده، پیشبینی می کنند و در نهایت از هر کدام یک 
    confusion matrix
    بر می گردانند که همان جدول 
    درست را درست پیشبینی کردن و درست را غلط پیشبینی کردن و غلط را درست پیشبینی کردن و غلط را غلط پیشبیی کردن است.
    و نتیجه هر کدام در خروجی آمده است و با این روش ها هم میشد پیشبینی هایی انجام داد.
</font></div>


```python
# importing libraries
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LogisticRegression

# importing dataset
col_list = ['Embarked', 'Parch', 'SibSp', 'Pclass', 'Sex', 'Survived']
dataset = pd.read_csv('titanic.csv', usecols=col_list)
X = dataset.iloc[:, 1:].values  # independent variable matrix
Y = dataset.iloc[:, 0].values  # dependent variable vector

# Handling missing data
imputer = SimpleImputer(missing_values=np.nan, strategy='most_frequent')
imputer = imputer.fit(X[:, :])
X[:, :] = imputer.transform(X[:, :])

# Encoding categorical data
labelencoder_X = LabelEncoder()
X[:, 1] = labelencoder_X.fit_transform(X[:, 1])
X[:, 4] = labelencoder_X.fit_transform(X[:, 4])

ct = ColumnTransformer([('one_hot_encoder', OneHotEncoder(categories='auto'), [0])], remainder='passthrough')
X = ct.fit_transform(X)

labelencoder_y = LabelEncoder()
Y = labelencoder_y.fit_transform(Y)

# Spliting dataset into training set and testing test
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=0)

# feature scaling
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)

# -----------------------------------------------------------------------------------------------------------------------
# using K-Nearest Neighbors

# Fitting K-NN to the Training set
classifier = KNeighborsClassifier(n_neighbors=5, metric='minkowski', p=2)
classifier.fit(X_train, Y_train)

# Predicting the Test set results
Y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
cm = confusion_matrix(Y_test, Y_pred)
print("with K-Nearest Neighbors")
print(cm)

# -----------------------------------------------------------------------------------------------------------------------
# Support Vector Machine

# Fitting SVM to the Training set
classifier = SVC(kernel='linear', random_state=0)
classifier.fit(X_train, Y_train)

# Predicting the Test set results
Y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
cm = confusion_matrix(Y_test, Y_pred)
print("with Support Vector Machine")
print(cm)

# -----------------------------------------------------------------------------------------------------------------------
# Kernel SVM

# Fitting Kernel SVM to the Training set
classifier = SVC(kernel='rbf', random_state=0)
classifier.fit(X_train, Y_train)

# Predicting the Test set results
Y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
cm = confusion_matrix(Y_test, Y_pred)
print("with kernel SVM")
print(cm)

# -----------------------------------------------------------------------------------------------------------------------
# Decision Tree Classification

# Fitting Decision Tree Classification to the Training set
classifier = DecisionTreeClassifier(criterion='entropy', random_state=0)
classifier.fit(X_train, Y_train)

# Predicting the Test set results
Y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
cm = confusion_matrix(Y_test, Y_pred)
print("with decision tree classification")
print(cm)

# -----------------------------------------------------------------------------------------------------------------------
# Random Forest Classification

# Fitting Random Forest Classification to the Training set
classifier = RandomForestClassifier(n_estimators=10, criterion='entropy', random_state=0)
classifier.fit(X_train, Y_train)

# Predicting the Test set results
Y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
cm = confusion_matrix(Y_test, Y_pred)
print("with random forest classification")
print(cm)

# -----------------------------------------------------------------------------------------------------------------------
# Polynomial Linear Regression

# Fitting Linear Regression to the data set
lin_reg = LinearRegression()
lin_reg.fit(X_train, Y_train)

# Fitting Polynomial Linear Regression to the data set
poly_reg = PolynomialFeatures(degree=4)
X_poly = poly_reg.fit_transform(X_train)
lin_reg_2 = LinearRegression()
lin_reg_2.fit(X_poly, Y_train)

# Visualising the Linear Regression results
lin_pred = lin_reg.predict(X_test)
lin_pred = lin_pred.tolist()
for i in range(len(lin_pred)):
    if lin_pred[i] < 0.5:
        lin_pred[i] = 0
    else:
        lin_pred[i] = 1
cm = confusion_matrix(Y_test, lin_pred)
print("with linear regression")
print(cm)

# Visualising the Polynomial Regression results
poly_pred = lin_reg_2.predict(poly_reg.fit_transform(X_test))
poly_pred = poly_pred.tolist()
for i in range(len(lin_pred)):
    if poly_pred[i] < 0.5:
        poly_pred[i] = 0
    else:
        poly_pred[i] = 1
cm = confusion_matrix(Y_test, poly_pred)
print("with polynomial regression")
print(cm)

# -----------------------------------------------------------------------------------------------------------------------
# Logistic Regression

# making LogisticRegression Model
classifier = LogisticRegression(random_state=0)
classifier.fit(X_train, Y_train)

# making predictions on test data
y_predict = classifier.predict(X_test)

# confusion matrix
cm = confusion_matrix(Y_test, y_predict)
print("with logistic regression")
print(cm)

```

    with K-Nearest Neighbors
    [[100  10]
     [ 23  46]]
    with Support Vector Machine
    [[92 18]
     [20 49]]
    with kernel SVM
    [[97 13]
     [22 47]]
    with decision tree classification
    [[99 11]
     [22 47]]
    with random forest classification
    [[92 18]
     [18 51]]
    with linear regression
    [[93 17]
     [20 49]]
    with polynomial regression
    [[94 16]
     [27 42]]
    with logistic regression
    [[95 15]
     [21 48]]
    
